

function login() {

  var username = document.getElementById("username").value;
  var pwd = document.getElementById("password").value;
//  var remember = document.getElementById("remember").value;
  console.log(username);
  $.ajax({
        type: "GET",
        dataType: "json",//预期服务器返回的数据类型
        url: "/login_submit" ,
        data: {"username":username,"password":pwd},
        success: function (result) {
              window.location.href="/hello"
        },
        error : function() {
            alert("未知异常！");
        }
    });
}