# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.


def home(request):

    return render(request, "index.html")


def login(request):
    if request.method == "POST":
        username = request.POST.get("username", None)
        password = request.POST.get("pwd", None)
        print(username, password)
        return render(request, "index.html")

    return render(request, "cmdb/login.html")


def register(request):
    return render(request, "cmdb/register.html")
